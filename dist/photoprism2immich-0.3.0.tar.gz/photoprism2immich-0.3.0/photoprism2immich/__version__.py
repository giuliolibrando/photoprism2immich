# __version__.py
VERSION = '0.3.0'
