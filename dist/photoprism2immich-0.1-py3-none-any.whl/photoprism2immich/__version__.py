# __version__.py
VERSION = '0.0.1'
